import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {

        //To read the list of URls to be visited for counting the number of words
        File file = new File("C:/URLs.txt");
        Scanner sc = new Scanner(file);

        String line = "";
        String arr[];
        String words = "";
        HashMap<String, Integer> commonMap = new HashMap<>();

        System.out.println("Output #1");
        System.out.println("=============");
        while(sc.hasNextLine()) {
            String websiteAddress = sc.nextLine();
            System.out.println(websiteAddress);

            //Inside try block the URL is validated using toURI() method
            //Only if the URL is valid the next steps of counting the given words is proceeded
            try {
                new URL(websiteAddress).toURI();

                //To Connect to the URL once its valid
                URL url = new URL(websiteAddress);
                URLConnection con = url.openConnection();

                InputStream is = con.getInputStream();

                BufferedReader br = new BufferedReader(new InputStreamReader(is));

                HashMap<String, Integer> map = new HashMap<>();

                //Using the Buffered Reader each line of a Web Page is read one at a time
                while ((line = br.readLine()) != null) {

                    //Using the Jsoup library we can strip the text content visible on the screen
                    Document document = Jsoup.parse(line);
                    //
                    Element link = document.select("body").first();

                    //Using the text() method, the text contents are stored in an Array of Strings
                    if (!link.text().isEmpty()) {
                        words = link.text();

                        //Performing a split on the String and storing as elements in an array
                        arr = words.split(" ");
                        String str = arr.toString();

                        //Storing Each Element in the Array as a Key in a HashMap
                        //And Updating its value based on its number of occurrence in the web page
                        //If the String doesn't exist, add the String as key and set its value as 1
                        //If it already exists, update its value (increment by 1)
                        for (int i = 0; i < arr.length; i++) {
                            //String search = "GeeksforGeeks";
                            if (!map.containsKey(arr[i])) {
                                map.put(arr[i], 1);
                            } else {
                                //System.out.println("Inside Else Part");
//                                if(arr[i].contentEquals(search)){
//                                    System.out.println(map.get(arr[i]));
//                                }
                                int count = map.get(arr[i]);
                                map.put(arr[i], count + 1);
                            }
                        }

                        //Same process as above but maintaining a global HashMap
                        //To keep track of the count of words across web pages
                        for (int i = 0; i < arr.length; i++) {
                            if (!commonMap.containsKey(arr[i])) {
                                commonMap.put(arr[i], 1);
                            } else {
                                int count = commonMap.get(arr[i]);
                                commonMap.put(arr[i], count + 1);
                            }
                        }

                    }
                }


                //sortedMap.entrySet().forEach(System.out::println);

                //Reading the list of words
                File file2 = new File("C:/Words.txt");
                Scanner sc2 = new Scanner(file2);
                HashMap<String, Integer> wordsCount = new HashMap<>();

                while (sc2.hasNextLine()) {
                    String key = sc2.nextLine();

                    //Searching if the hashmap contains the words given in the file
                    //If it exists, get the key's corresponding value and store it in a new HashMap
                    if (map.containsKey(key)) {
                        int value = map.get(key);
                        wordsCount.put(key, value);
                    }
                }

                //Sort the HashMap containing the given words and its count in descending order
                Map<String, Integer> occurrences = wordsCount.entrySet().stream()
                        .sorted(Comparator.comparingInt(e -> -e.getValue()))
                        .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                Map.Entry::getValue,
                                (a, b) -> {
                                    throw new AssertionError();
                                },
                                LinkedHashMap::new
                        ));

                //Printing the top three most occurred elements from the given list
                if (occurrences.size() < 1) {
                    System.out.println("There are no elements on the webpage that match the given words list !");
                } else {
                    int j = 0;
                    for (String key : occurrences.keySet()) {
                        if (j > 2) break;
                        occurrences.get(key);
                        j++;
                        System.out.println(key + " " + occurrences.get(key));
                    }
                }
                System.out.println("====================================");

            }
            //To Handle Invalid urls
            catch (Exception e) {
                System.out.println("Provided invalid URL Pattern!!");
                System.out.println("====================================");
                //e.printStackTrace();
            }


        //Setting the variables to null in order to used for a new content
        line = "";
        words = "";
        arr = null;
        }
        //Another method to display the overall count of words across web pages
        Main.display2(commonMap);


    }


    public static void display2(HashMap<String, Integer> commonMap) throws FileNotFoundException {

        System.out.println("============");
        System.out.println("Output #2");
        System.out.println("============");
        File file = new File("C:/Words.txt");
        Scanner sc = new Scanner(file);
        HashMap<String, Integer> wordsCount = new HashMap<>();

        while (sc.hasNextLine()) {
            String key = sc.nextLine();
            if (commonMap.containsKey(key)) {
                //System.out.println("The key is: "+key);
                //System.out.println("The Value  is: "+map.get(key));
                int value = commonMap.get(key);
                wordsCount.put(key, value);
            }
        }

        //Sort the HashMap containing
        Map<String, Integer> occurrences = wordsCount.entrySet().stream()
                .sorted(Comparator.comparingInt(e -> -e.getValue()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (a, b) -> {
                            throw new AssertionError();
                        },
                        LinkedHashMap::new
                ));

        if (occurrences.size() < 1) {
            System.out.println("There are no elements on the webpage that match the given words list !");
        } else {
            //int j = 0;
            for (String key : occurrences.keySet()) {
                //if (j > 2) break;
                occurrences.get(key);
                //j++;
                System.out.println(key + " " + occurrences.get(key));
            }
        }
        System.out.println("====================================");
    }
}
